<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style>
    
    body{
    margin: 0;
    background-image: url(https://th.bing.com/th/id/R.32d48920194b39df18fdfeea55611ead?rik=amsvhoXhweB2OA&riu=http%3a%2f%2fwww.rubellhotels.com%2fd%2frubellhotels%2fmedia%2fRepour_Bar%2f__thumbs_1600_1024_crop%2fAlbion-2015-016.jpg&ehk=qWBDYnFk6DnLsjW%2fmn%2bdFeGu29n9X0hPE5s%2bq10Ya68%3d&risl=&pid=ImgRaw);
    background-repeat: no-repeat;
    background-size: cover;
    font-family: var(--bs-font-sans-serif);
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #ffffff2e;
    -webkit-text-size-adjust: 100%;
    -webkit-tap-highlight-color: transparent;
    }
    </style>
    <title>Log in</title>
  </head>
  <body> 
<div class="container mb-3 col-md-6">
  <h1 class="container text-center" style="color: white; margin: inline start 2px;"><br>Log in</h1>
  <form action="" method="POST">
  <div class="container mb-3" style="width: 100%;"><br>
    <label for=uname" class="form-label"></label>
    <input type="email" class="form-control" id="uname" name="username" aria-describedby="emailHelp" placeholder="Username" >
  </div>
  <div class="container mb-3" style="width: 100%;">
    <label for="pass" class="form-label"></label>
    <input type="password" class="form-control" id="pass" name="password" placeholder="Password">
  </div><br>
  <div class="container mb-3" style="width: 100%;">
  <button type="submit" class="btn btn-primary col-md-12" style="background-color: #c59d5f; border-color:#c59d5f">Log in</button>
  </div>
</form>
  </div>

  
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php

include 'loginconnect.php';

?>