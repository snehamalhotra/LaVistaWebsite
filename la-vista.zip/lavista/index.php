<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial scale=1.0,
    maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>La Vista : Home</title>

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU"
        crossorigin="anonymous">
    <!--Scroll reveal CDN-->
    <script src="https://unpkg.com/scrollreveal"></script>
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
      <header>
        <div class="container">
          <nav class="nav">
            <div class="menu-toggle">
              <i class="fas fa-bars"></i>
              <i class="fas fa-times"></i>
            </div>
            <a href="index.html" class="logo"><img src="https://mail.google.com/mail/u/0?ui=2&ik=d641b36733&attid=0.1&permmsgid=msg-f:1705170572643561566&th=17a9fb99f7de705e&view=att&disp=safe&realattid=f_kr200hs10" alt="Logo"></a>
            <!--bsic structure of navigation bar-->
            <ul class="nav-list">
              <li class="nav-item">
              <a href="index.html" class="nav-link active">Home</a>
              </li>
              <li class="nav-item">
              <a href="menu.html" class="nav-link">Menu</a>
              </li>
              <li class="nav-item">
              <a href="login.php" class="nav-link">Log-In</a>
              </li>
              <li class="nav-item">
              <a href="signupnew.php" class="nav-link">Sign-Up</a>
              </li>
              <li class="nav-item">
              <a href="explore.html" class="nav-link">Gallery</a>
              </li>
              <li class="nav-item">
              <a href="contact.html" class="nav-link">Contact Us</a>
              </li>
            </ul>
          </nav>
        </div>
      </header>
      <!--header ends-->
      <section class="hero" id="hero">
        <div class="container">
          <h2 class="sub-headline">
            <span class="first-letter">W</span>elcome
          </h2>
          <h1 class="headline">La Vista</h1>
          <div class="headline-desciption">
            <div class="separator">
               <div class="line line-left"></div>
               <div class="asterisk"><i class="fas fa-asterisk"></i></div>
               <div class="line line-right"></div>
            </div>
            <div class="single-animation">
              <h5>Paradise on your Plate.</h5>
              <a href="explore.html" class="btn cta-btn">Explore</a>
            </div>
          </div>
        </div>
      </section>
      <!--hero ends-->
      <section class="discover-our-story">
        <div class="container">
          <div class="restaurant-info">
            <div class="restaurant-description padding-right animate-left">
              <div class="global-headline">
                <h2 class="sub-headline">
                  <span class="first-letter">D</span>iscover
                </h2>
                <h1 class="headline headline-dark">Our Story</h1>
                <div class="asterisk"><i class="fas fa-asterisk"></i></div>
              </div>
              <p>
                <strong>Hola!</strong> - as they say in Spain.
              </p>
              <p>
                For those customers who have dined at <strong>La Vista</strong> restaurant before,
                   welcome back. If this is your first visit, a very warm welcome
                    and we hope you enjoy your dining experience with us.
              </p>
              <a href="aboutus.html" class="btn body-btn">About Us</a>
            </div>
            <div class="restaurant-info-img animate-right">
              <img src="../images/our-story-1.jpg.jpeg" alt="our story">
            </div>
          </div>
        </div>
      </section>
      <!--discover our story ends-->
      <section class="tasteful-recipes between">
        <div class="container">
          <div class="global-headline">
            <div class="animate-top">
              <h2 class="sub-headline">
                <span class="first-letter">T</span>asteful
              </h2>
            </div>
            <div class="animate-bottom">
              <h1 class="headline">Recipes</h1>
            </div>
          </div>
        </div>
      </section>
      <!--Tasteful recipes ends-->
      <section class="discover-our-menu">
        <div class="container">
          <div class="restaurant-info">
            <div class="image-group padding-right animate-left">
              <img src="../images/menu-group-1.jpg.jpeg" alt="">
              <img src="../images/menu-group-2.jpg.jpeg" alt="">
              <img src="../images/menu-group-3.jpg.jpeg" alt="">
              <img src="../images/menu-group-4.jpg.jpeg" alt="">
            </div>
            <div class="restaurant-desciption animate-right">
              <div class="global-headline">
                <h2 class="sub-headline">
                  <span class="first-letter">D</span>iscover
                </h2>
                <h1 class="headline headline-dark">Menu</h1>
                <div class="asterisk"><i class="fas fa-asterisk"></i></div>
              </div>
              <p>
                Welcome to <strong>La Vista</strong> where we serve fresh,
                delicious food prepared with the finest ingredients. Relax,
                indulge and enjoy our mouth-watering dishes within beautiful
                yet comfortable surroundings.
              </p>
              <a href="menu.html" class="btn body-btn">View the full menu</a>
            </div>
          </div>
        </div>
      </section>
      <!--Discover our menu ends-->
      <section class="perfect-blend between">
        <div class="container">
          <div class="global-headline">
            <div class="animate-top">
              <h2 class="sub-headline">
                <span class="first-letter">T</span>he Perfect
              </h2>
            </div>
            <div class="animate-bottom">
              <h1 class="headline">Blend</h1>
            </div>
          </div>
        </div>
      </section>
      <!--Perfect blend ends-->
      <section class="culinary-delight">
        <div class="container">
          <div class="restaurant-info">
            <div class="restaurant-description padding-right animate-left">
              <div class="global-headline">
                <h2 class="sub-headline">
                  <span class="first-letter">C</span>ulinary
                </h2>
                <h1 class="headline headline-dark">Delight</h1>
                <div class="asterisk"><i class="fas fa-asterisk"></i></div>
              </div>
              <p>
                Whether you are planning a romantic dinner for two, a special
                night out for a group of friends or a morning meet-up with
                family, we have something special for every occasion.
              </p>
              <a href="form.html" class="btn body-btn">Make a reservation</a>
            </div>
            <div class="image-group">
              <img class="animate-top" src="../images/delight-group-1.jpg.jpeg" alt="">
              <img class="animate-bottom" src="../images/delight-group-2.jpg.jpeg" alt="">
            </div>
          </div>
        </div>
      </section>
      <!--Culinary delight ends-->
      <footer>
        <div class="container">
          <div class="back-to-top">
            <a href="#hero"><i class="fas fa-chevron-up"></i></a>
          </div>
          <div class="footer-content">
            <div class="footer-content-about animate-top">
              <h4>OPEN HOURS</h4>
              <p>Our restaurant is now open throughout the week with extra weekend hours.</p>
              <h2 style="font-weight: 50; color: var(--secondary-font-color);">Monday to Thursday:  8:30 am - 9:00pm</h2>
              <h2 style="font-weight: 50; color: var(--secondary-font-color);">Friday to Sunday:  9:00 am - 10:30 pm</h2>
            </div>
            <div class="footer-content-divider animate-bottom">
              <div class="social-media">
                <h4>Follow Along</h4>
                <ul class="social-icons">
                  <li>
                    <a href="https://twitter.com/la_viewpoint?s=09"><i class="fab fa-twitter"></i></a>
                  </li>
                  <li>
                    <a href="https://www.facebook.com/La_vista96-107929198225665/"><i class="fab fa-facebook-square"></i></a>
                  </li>
                  <li>
                    <a href="https://pin.it/1cjytvg"><i class="fab fa-pinterest"></i></a>
                  </li>
                  <li>
                    <a href="https://instagram.com/la_vista96?utm_medium=copy_link"><i class="fab fa-instagram"></i></a>
                  </li>
                  <li>
                    <a href="https://www.tripadvisor.in/Profile/la_vista96"><i class="fab fa-tripadvisor"></i></a>
                  </li>
                </ul>
              </div>
              <div class="newsletter-container">
                <h4>Newsletter</h4>
                <form class="newsletter-form" action="mailto:drishti.s1703@gmail.com">
                  <input type="text" class="newsletter-input" placeholder="Your email address...">
                  <button type="submit" class="newsletter-btn">
                    <i class="fas fa-envelope"></i>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <script src="main.js"></script>
  </body>
</html>